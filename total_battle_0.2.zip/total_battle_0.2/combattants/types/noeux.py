from combattants.types.classifi import*
from combattants.types.tours import Tour, Stats_Tour
from combattants.types.cavalier import Cavalier, Stats_cavalier
from combattants.types.piquiers import Piquiers, Stats_piquier
from combattants.types.elite import Elite, Stats_elite
from combattants.types.archets import Archet, Stats_archets
from combattants.types.heros import Heros, Stats_heros
from combattants.types.tireur_monte import Tireur_monte, Stats_monte